package com.db.myPage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class PetListDB {
	
	private static PetListDB instance = new PetListDB();
	
	public static PetListDB getInstance() {
		return instance;
	}
	
	public PetListDB() {}
	
	String url = "jdbc:oracle:thin:@168.126.146.52:1521:orcl";
	String user = "20192118", pwd="001220";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	
	String sql = "";
	String sql2 = "";
	String result = "test";
	
	Date date;
	String birthday_string = "";
	
	SimpleDateFormat Parseformatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	
	ArrayList <Pet> myList = new ArrayList <>();
	
	public ArrayList<Pet> connectionDB(String userId) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pwd);
			
			sql = "SELECT PNO, PETNAME, PETBIRTHDAY, PETIMG FROM PET_PETMEMBER WHERE USERId=? ORDER BY PNO";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int pno = rs.getInt("pno");
				String petname = rs.getString("petname");
				String birthday = rs.getString("petbirthday");
				String img = rs.getString("petimg");
				
				date = Parseformatter.parse(birthday);
				birthday_string = formatter.format(date);
				
				Pet pet = new Pet(pno, petname, birthday_string, img);
				myList.add(pet);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}catch(SQLException ex) {}
			}
			
			if(conn != null) {
				try {
					conn.close();
				}catch(SQLException ex) {}
			}
		}return myList; 
	}

}
