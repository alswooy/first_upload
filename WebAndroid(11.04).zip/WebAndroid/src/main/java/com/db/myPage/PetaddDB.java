package com.db.myPage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PetaddDB {
	
	private static PetaddDB instance = new PetaddDB();
	
	public static PetaddDB getInstance() {
		return instance;
	}
	
	public PetaddDB() {}
	
	String url = "jdbc:oracle:thin:@168.126.146.52:1521:orcl";
	String user = "20192118", pwd="001220";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	
	String sql = "";
	String sql2 = "";
	String result = "test";
	
	public String connectionDB(String userId, String petname, String petbirthday, String pettype, String petmemo, String petsex, String petimg) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pwd);
			
			sql = "SELECT USERId FROM PET_PETMEMBER WHERE USERId=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				String no ="SELECT COALESCE(MAX(pno), 0) + 1 AS pno FROM PET_PETMEMBER";
				sql2 = "INSERT INTO PET_PETMEMBER(PNO, USERID, PETNAME, PETBIRTHDAY, PETTYPE, PETMEMO, PETSEX, PETIMG) VALUES((" + no + "), ?, ?, ?, ?, ?, ?, ?)";
				pstmt2 = conn.prepareStatement(sql2);
				pstmt2.setString(1, userId);
				pstmt2.setString(2, petname);
				pstmt2.setString(3, petbirthday);
				pstmt2.setString(4, pettype);
				pstmt2.setString(5, petmemo);
				pstmt2.setString(6, petsex);
				pstmt2.setString(7, petimg);
				pstmt2.executeUpdate();
				result = "success";
			}else {
				result = "fail";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt2 != null) {
				try {
					pstmt2.close();
				}catch(SQLException ex) {}
			}
			
			if(pstmt != null) {
				try {
					pstmt.close();
				}catch(SQLException ex) {}
			}
			
			if(conn != null) {
				try {
					conn.close();
				}catch(SQLException ex) {}
			}
		}return result; 
	}

}
