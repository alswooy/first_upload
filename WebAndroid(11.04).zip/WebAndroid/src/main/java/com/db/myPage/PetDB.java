package com.db.myPage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class PetDB {
	
	private static PetDB instance = new PetDB();
	
	public static PetDB getInstance() {
		return instance;
	}
	
	public PetDB() {}
	
	String url = "jdbc:oracle:thin:@168.126.146.52:1521:orcl";
	String user = "20192118", pwd="001220";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	
	String sql = "";
	String sql2 = "";
	String result = "test";
	
	Date date;
	String birthday_string = "";
	
	SimpleDateFormat Parseformatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	
	
	ArrayList <Pet> myList = new ArrayList <Pet>();
	
	public ArrayList<Pet> connectionDB(String userId, int petPno) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pwd);
			
			sql = "SELECT PETNAME, PETBIRTHDAY, PETTYPE, PETMEMO, PETSEX, PETIMG FROM PET_PETMEMBER WHERE USERId=? AND PNO=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setInt(2, petPno);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				String petname = rs.getString("petname");
				String birthday = rs.getString("petbirthday");
				String type = rs.getString("pettype");
				String memo = rs.getString("petmemo");
				String sex = rs.getString("petsex");
				String img = rs.getString("petimg");
				
				date = Parseformatter.parse(birthday);
				birthday_string = formatter.format(date);
				
				Pet pet = new Pet(petname, birthday_string, type, memo, sex, img);
				myList.add(pet);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}catch(SQLException ex) {}
			}
			
			if(conn != null) {
				try {
					conn.close();
				}catch(SQLException ex) {}
			}
		}return myList; 
	}

}
