package com.db.myPage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Pet {
	
	private int pno;
	private String petname;
	private String birthday;
	private String pettype;
	private String petmemo;
	private String petsex;
	private String petImg;
	
	public Pet(String petname, String birthday, String pettype, String petmemo, String petsex, String petImg) {
		this.petname = petname;
		this.birthday = birthday;
		this.pettype = pettype;
		this.petmemo = petmemo;
		this.petsex = petsex;
		this.petImg = petImg;
		
	}
	
	public Pet(int pno, String petname, String birthday, String petImg) {
		this.pno = pno;
		this.petname = petname;
		this.birthday = birthday;
		this.petImg = petImg;
	}
	
	public String getPetname() {
		return petname;
	}
	public void setPetname(String petname) {
		this.petname = petname;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getPettype() {
		return pettype;
	}
	public void setPettype(String pettype) {
		this.pettype = pettype;
	}
	public String getPetmemo() {
		return petmemo;
	}
	public void setPetmemo(String petmemo) {
		this.petmemo = petmemo;
	}
	public String getPetsex() {
		return petsex;
	}
	public void setPetsex(String petsex) {
		this.petsex = petsex;
	}
	public String getPetImg() {
		return petImg;
	}
	public void setPetImg(String petImg) {
		this.petImg = petImg;
	}

	public int getPno() {
		return pno;
	}

	public void setPno(int pno) {
		this.pno = pno;
	}
	
	


	
	
	

}
