package com.db.community;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class BoardListDB {
	
	private static BoardListDB instance = new BoardListDB();
	
	public static BoardListDB getInstance() {
		return instance;
	}
	
	public BoardListDB() {}
	
	String url = "jdbc:oracle:thin:@168.126.146.52:1521:orcl";
	String user = "20192118", pwd="001220";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	
	String sql = "";
	String sql2 = "";
	String result = "test";
	
	Date date;
	String regDate_string = "";
	
	SimpleDateFormat Parseformatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	
	ArrayList <Board> myList = new ArrayList <>();
	
	public ArrayList<Board> connectionDB() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pwd);
			
			sql = "SELECT BNO, TITLE, REPLYCNT, RECOMMENDCNT, WRITERNICKNAME, REGDATE, USERID FROM PET_BOARD WHERE DEL_YN='n' ORDER BY BNO DESC";
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int bno = rs.getInt("bno");
				String title = rs.getString("title");
				int replycnt = rs.getInt("replycnt");
				int recommendcnt = rs.getInt("recommendcnt");
				String writerNickname = rs.getString("writerNickname");
				String regDate = rs.getString("regDate");
				String userId = rs.getString("userid");
				
				date = Parseformatter.parse(regDate);
				regDate_string = formatter.format(date);
				
				Board board = new Board(bno, title, replycnt, recommendcnt, writerNickname, regDate_string, userId);
				myList.add(board);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}catch(SQLException ex) {}
			}
			
			if(conn != null) {
				try {
					conn.close();
				}catch(SQLException ex) {}
			}
		}return myList; 
	}

}
