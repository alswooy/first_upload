package com.db.community;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class BoardLikeAddDB {
	
	private static BoardLikeAddDB instance = new BoardLikeAddDB();
	
	public static BoardLikeAddDB getInstance() {
		return instance;
	}
	
	public BoardLikeAddDB() {}
	
	String url = "jdbc:oracle:thin:@168.126.146.52:1521:orcl";
	String user = "20192118", pwd="001220";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	PreparedStatement pstmt3 = null;
	ResultSet rs = null;
	
	String sql = "";
	String sql2 = "";
	String sql3 = "";
	String result = "test";
	
	public String connectionDB(int bno, String userId) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pwd);
			
			sql = "SELECT BLNO FROM PET_BOARDLIKE WHERE BNO=? AND USERID=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bno);
			pstmt.setString(2, userId);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = "fail";
			}else {
				String blno ="SELECT COALESCE(MAX(blno), 0) + 1 AS blno FROM PET_BOARDLIKE";
				sql2 = "INSERT INTO pet_boardlike (blno, bno, userId) VALUES((" + blno + "), ?, ?)";
				pstmt2 = conn.prepareStatement(sql2);
				pstmt2.setInt(1, bno);
				pstmt2.setString(2, userId);
				pstmt2.executeQuery();
				
				sql3 = "UPDATE PET_BOARD SET RECOMMENDCNT = RECOMMENDCNT+1 WHERE BNO = ?";
				pstmt3 = conn.prepareStatement(sql3);
				pstmt3.setInt(1, bno);
				pstmt3.executeUpdate();
				
				result = "success";
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}catch(SQLException ex) {}
			}
			if(pstmt2 != null) {
				try {
					pstmt2.close();
				}catch(SQLException ex) {}
			}
			if(pstmt3 != null) {
				try {
					pstmt3.close();
				}catch(SQLException ex) {}
			}
			
			if(conn != null) {
				try {
					conn.close();
				}catch(SQLException ex) {}
			}
		}return result; 
	}

}
