package com.db.community;

public class Board {
	
	private int bno;
	private String title;
	private String content;
	private int replycnt=0;
	private int recommendcnt=0;
	private String writerNickname;
	private String regDate;
	private char del_yn='n';
	private String userid;
	
	public Board(int bno, String title, int replycnt, int recommendcnt, String writerNickname, String regDate, String userid) {
		this.bno = bno;
		this.title = title;
		this.replycnt = replycnt;
		this.recommendcnt = recommendcnt;
		this.writerNickname = writerNickname;
		this.regDate = regDate;
		this.userid = userid;
	}
	
	public Board(String title, String content, int replycnt, int recommendcnt, String writerNickname, String regDate, String userid) {
		this.title = title;
		this.content = content;
		this.replycnt = replycnt;
		this.recommendcnt = recommendcnt;
		this.writerNickname = writerNickname;
		this.regDate = regDate;
		this.userid = userid;
	}
	
	
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getReplycnt() {
		return replycnt;
	}
	public void setReplycnt(int replycnt) {
		this.replycnt = replycnt;
	}
	public int getRecommendcnt() {
		return recommendcnt;
	}
	public void setRecommendcnt(int recommendcnt) {
		this.recommendcnt = recommendcnt;
	}
	public String getWriterNickname() {
		return writerNickname;
	}
	public void setWriterNickname(String writerNickname) {
		this.writerNickname = writerNickname;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public char getDel_yn() {
		return del_yn;
	}
	public void setDel_yn(char del_yn) {
		this.del_yn = del_yn;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	


	
	
	

}
