package com.db.community;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BoardaddDB {
	
	private static BoardaddDB instance = new BoardaddDB();
	
	public static BoardaddDB getInstance() {
		return instance;
	}
	
	public BoardaddDB() {}
	
	String url = "jdbc:oracle:thin:@168.126.146.52:1521:orcl";
	String user = "20192118", pwd="001220";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	
	String sql = "";
	String sql2 = "";
	String result = "test";
	String nickName = "";
	
	public String connectionDB(String userId, String title, String content) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pwd);
			
			sql = "SELECT NICKNAME FROM PET_MEMBER WHERE USERId=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				nickName = rs.getString(1);
				
				String no ="SELECT COALESCE(MAX(bno), 0) + 1 AS bno FROM PET_BOARD";
				sql2 = "INSERT INTO PET_BOARD(BNO, USERID, TITLE, CONTENT, WRITERNICKNAME) VALUES((" + no + "), ?, ?, ?, ?)";
				pstmt2 = conn.prepareStatement(sql2);
				System.out.println("id : " + userId + " title :" + title + " content :" + content + " nickname : " + nickName);
				pstmt2.setString(1, userId);
				pstmt2.setString(2, title);
				pstmt2.setString(3, content);
				pstmt2.setString(4, nickName);
				pstmt2.executeUpdate();
				result = "success";
			}else {
				result = "fail";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt2 != null) {
				try {
					pstmt2.close();
				}catch(SQLException ex) {}
			}
			
			if(pstmt != null) {
				try {
					pstmt.close();
				}catch(SQLException ex) {}
			}
			
			if(conn != null) {
				try {
					conn.close();
				}catch(SQLException ex) {}
			}
		}return result; 
	}

}
