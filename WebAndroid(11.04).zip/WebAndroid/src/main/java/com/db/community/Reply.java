package com.db.community;

public class Reply {
	
	private int rno;
	private int bno;
	private String content;
	private int recommendcnt;
	private String writerNickname;
	private String regDate;
	private char del_yn='n';
	private String userid;
	
	public Reply(int rno, String content, int recommendcnt, String writerNickname, String regDate, String userid) {
		this.rno = rno;
		this.content = content;
		this.recommendcnt = recommendcnt;
		this.writerNickname = writerNickname;
		this.regDate = regDate;
		this.userid = userid;
	}

	
	
	public int getRno() {
		return rno;
	}

	public void setRno(int rno) {
		this.rno = rno;
	}

	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}

	public int getRecommendcnt() {
		return recommendcnt;
	}
	public void setRecommendcnt(int recommendcnt) {
		this.recommendcnt = recommendcnt;
	}
	public String getWriterNickname() {
		return writerNickname;
	}
	public void setWriterNickname(String writerNickname) {
		this.writerNickname = writerNickname;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public char getDel_yn() {
		return del_yn;
	}
	public void setDel_yn(char del_yn) {
		this.del_yn = del_yn;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	


	
	
	

}
