package com.db.user;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnectJoinDB {
	
	private static ConnectJoinDB instance = new ConnectJoinDB();
	
	public static ConnectJoinDB getInstance() {
		return instance;
	}
	
	public ConnectJoinDB() {}
	
	String url = "jdbc:oracle:thin:@168.126.146.52:1521:orcl";
	String user = "20192118", pwd="001220";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	
	String sql = "";
	String sql2 = "";
	String result = "test";
	
	public String connectJoinDB(String userId, String userPwd, String name, String nickname, String phone) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pwd);
			
			sql = "SELECT userId FROM PET_MEMBER WHERE userId=? OR nickname=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			pstmt.setString(2, nickname);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = "fail";
			}else {
				String no ="SELECT COALESCE(MAX(mno), 0) + 1 AS mno FROM PET_MEMBER";
				sql2 = "INSERT INTO PET_MEMBER(MNO, USERID, PASSWD, NAME, PHONE, NICKNAME) VALUES((" + no + "), ?, ?, ?, ?, ?)";
				pstmt2 = conn.prepareStatement(sql2);
				pstmt2.setString(1, userId);
				pstmt2.setString(2, userPwd);
				pstmt2.setString(3, name);
				pstmt2.setString(4, phone);
				pstmt2.setString(5, nickname);
				pstmt2.executeUpdate();
				result = "success";
			}
		
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt2 != null) {
				try {
					pstmt2.close();
				}catch(SQLException ex) {}
			}
			if(pstmt != null) {
				try {
					pstmt.close();
				}catch(SQLException ex) {}
			}
			
			if(conn != null) {
				try {
					conn.close();
				}catch(SQLException ex) {}
			}
		}return result;
	}

}
