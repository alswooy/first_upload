package com.db.user;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class IdFindDB {
	
	private static IdFindDB instance = new IdFindDB();
	
	public static IdFindDB getInstance() {
		return instance;
	}
	
	public IdFindDB() {}
	
	String url = "jdbc:oracle:thin:@168.126.146.52:1521:orcl";
	String user = "20192118", pwd="001220";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	
	String sql = "";
	String sql2 = "";
	String result = "test";
	String id_result = "test";
	String regdate_result = "test";
	Date date;
	String regdate_string = "";
	
	SimpleDateFormat Parseformatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	
	public String connectionDB(String name, String phone) {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pwd);
			
			sql = "SELECT USERId, REGDATE FROM PET_MEMBER WHERE NAME=? AND PHONE=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, phone);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = "success";
				id_result = rs.getString(1);
				regdate_result = rs.getString(2);
				date = Parseformatter.parse(regdate_result);
				regdate_string = formatter.format(date);
			}else {
				result = "fail";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}catch(SQLException ex) {}
			}
			
			if(conn != null) {
				try {
					conn.close();
				}catch(SQLException ex) {}
			}
		}
		
		return result + "/" + id_result + "/" + regdate_string;
	}

}
