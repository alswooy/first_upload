package com.db.user;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NicknameCheckDB {
	
	private static NicknameCheckDB instance = new NicknameCheckDB();
	
	public static NicknameCheckDB getInstance() {
		return instance;
	}
	
	public NicknameCheckDB() {}
	
	String url = "jdbc:oracle:thin:@168.126.146.52:1521:orcl";
	String user = "20192118", pwd="001220";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	
	String sql = "";
	String sql2 = "";
	String result = "test";
	
	public String connectionDB(String nickname) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pwd);
			
			sql = "SELECT NICKNAME FROM PET_MEMBER WHERE NICKNAME=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nickname);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = "fail";
			}else {
				result = "success";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}catch(SQLException ex) {}
			}
			
			if(conn != null) {
				try {
					conn.close();
				}catch(SQLException ex) {}
			}
		}return result;
	}

}
