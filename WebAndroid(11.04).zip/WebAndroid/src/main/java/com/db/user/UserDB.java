package com.db.user;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDB {
	
	private static UserDB instance = new UserDB();
	
	public static UserDB getInstance() {
		return instance;
	}
	
	public UserDB() {}
	
	String url = "jdbc:oracle:thin:@168.126.146.52:1521:orcl";
	String user = "20192118", pwd="001220";
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	PreparedStatement pstmt2 = null;
	ResultSet rs = null;
	
	String sql = "";
	String sql2 = "";
	String result = "test";
	
	String name_result = "test";
	String phone_result = "test";
	String nickname_result = "test";
	
	public String connectionDB(String userId) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pwd);
			
			sql = "SELECT NAME, PHONE, NICKNAME FROM PET_MEMBER WHERE USERId=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userId);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = "success";
				name_result = rs.getString(1);
				phone_result = rs.getNString(2);
				nickname_result = rs.getString(3);
			}else {
				result = "fail";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt != null) {
				try {
					pstmt.close();
				}catch(SQLException ex) {}
			}
			
			if(conn != null) {
				try {
					conn.close();
				}catch(SQLException ex) {}
			}
		}return result + "/" + name_result + "/" + phone_result + "/" + nickname_result; 
	}

}
